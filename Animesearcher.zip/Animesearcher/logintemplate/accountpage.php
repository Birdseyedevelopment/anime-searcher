<?php
 require_once ('User.php');
 require_once ('function.php');
 session_start();
 use Edu\Ccp\Cis244\login\User;
 use function edu\ccp\cis44\login\functions\userisloggedIn;
 use function edu\ccp\cis44\login\functions\h;

 if (userisloggedIn()){
    $user = User::getUserbyId($_SESSION['user_id']);
    } else {
        header('Location:login.php');
        die;

    }
 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Page</title>
</head>
<body>
    <nav><a href="logout.php">Logout</a></nav>
    <h1>This is your account page</h1>
    <p>Hello you are logged in as</p>
    <p><?php print h($user->getUsername());?></p>
</body>
</html>