DROP TABLE IF EXISTS user;
CREATE TABLE user(
user_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
username TEXT  not null unique,
password TEXT not null 
);


INSERT INTO user (username, password) VALUES
	('aturing',	'$2y$10$Cr9ExVyFIMp2xbpmP8eUi.gJOV1pPfRTQCF1JG1HMODo3XCxv7KCi'),
	('alice',	'$2y$10$x1310rsmoMXlXaemo7sEtuafP6xP0OQ64e2rS3YJ0yVxAIjM7OxQW'),
	('bob',	    '$2y$10$Ukzpl0HQRZCSTxWaLC.MhOv.X8jFx9YWah.y/1XlhZu.qTzDCLthC'),
	('carol',	'$2y$10$SXevr.S.kNuvIj5dCSgH2eOYbkBgyncot4SdJQupxsK7FmIjcwlSK'); 