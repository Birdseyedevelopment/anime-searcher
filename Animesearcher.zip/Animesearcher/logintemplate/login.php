<?php
require_once ('User.php');
require_once ('function.php');
session_start();
use Edu\Ccp\Cis244\login\User;
use function edu\ccp\cis44\login\functions\userisloggedIn;

if (userisloggedIn()){
        header('Location:../index.php');
        die;

    }


if(isset($_POST['login'])){
    $username = $_POST['username']??'';
    $password = $_POST['password']??'';
    $user = User::getuserbyLogincredentials($username, $password);
    if ($user){
       $_SESSION['user_id'] = $user->getId();
       header('Location:../index.php');
       die;
    }else{
        $errormessage = 'The username or password is incorrect';
    }
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../styles.css">
    <title>Login Page</title>
</head>
<body>
<div class = loginhead>    
<p><a href="register.php">New User Register Here</a></p>
    <h1>Log in to continue</h1>
    <?php if(isset($errormessage)):?>
        <h2 style="color:red;"><?php print $errormessage; ?></h2>
        <?php endif?>
        </div>
    <form method="POST">
        <div>
            <label for="username">Username</label>
            <br>
            <input id="username" name="username">
        </div>
        <div>
            <label for="password">Password</label>
            <br>
            <input type="password" id="password" name="password">
        </div>   
         <div>
            <input type="submit" id="login" name="login" value="Log In">
        </div>
    </form>
</body>
</html>