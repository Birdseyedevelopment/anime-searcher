<?php
namespace edu\ccp\cis44\login\functions;
function userisloggedIn(){
    return (isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0);
}

function h($value){
    return htmlentities($value);
}

?>