<?php
namespace Edu\Ccp\Cis244\login;
Class User{
    private $id;
    private $username;
    private const CONNECTION = 'sqlite:user.db';

    static function getconnection(){
        return new \PDO(User::CONNECTION);
    }

    static function getUserbyId($id){
        $connection =User::getconnection();
        $query = $connection ->prepare('SELECT user_id, username 
        FROM user where user_id =:id
        LIMIT 1
        ');
        $query->bindParam(':id',$id, \PDO::PARAM_INT);
        $query->execute();
        $result = $query->fetch(\PDO::FETCH_ASSOC);
        if($result){
        return new User ($result['user_id'], $result['username']);
    }else {
        return null;
    }  
    }

    static function usernameIsAvailable($username){
        $connection =User::getconnection();
        $query = $connection ->prepare('SELECT user_id
    FROM user where username = :username  Limit 1
    ');
    $query->execute([':username'=>$username]);
    $result = $query->fetchAll(\PDO::FETCH_ASSOC);
   return count($result) == 0;
    }

    static function createUser($username, $password){
        $connection =User::getconnection();
        $query = $connection ->prepare('INSERT INTO user (username, password)  
        values(:username, :password)
        ');
        $query->execute([':username'=>$username, 
        
        ':password' => password_hash($password, PASSWORD_DEFAULT),
        ]);
}
    static function passwordhasher($password){
      $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
    return $hashedpassword;
    }


    static function getuserbyLogincredentials($username, $password){
        $connection =User::getconnection();

    $query = $connection ->prepare('SELECT user_id, username, password
    FROM user where username = :username
    Limit 1
    ');
    $query->execute([':username'=>$username]);
    $result = $query->fetch(\PDO::FETCH_ASSOC);
    if($result && password_verify($password, $result['password'])){
    return new User ($result['user_id'], $result['username']);
}else {
    return null;
}  
    }



    function __construct($id, $username){

    $this->id=$id;
    $this->username = $username;
      
    }

    function getId(){
        return $this ->id;
    }
    
    function getUsername(){
        return $this->username;
    }

   
}