<?php
require_once ('User.php');
require_once ('function.php');
session_start();
use Edu\Ccp\Cis244\login\User;
use function edu\ccp\cis44\login\functions\userisloggedIn;
$errorMessages =[];

if (userisloggedIn()){
        header('Location:accountpage.php');
        die;

    }


if(isset($_POST['register'])){
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $Passwordconfirm = $_POST['password-verify'] ?? '';

    if(!User::usernameIsAvailable($username)){
      $errorMessages[] = 'username is taken';
    }

    if($password !== $Passwordconfirm){
        $errorMessages[] = 'passwords dont match';
    }

    if(count($errorMessages) === 0){
        User::createUser($username, $password);
        $user = User::getuserbyLogincredentials($username, $password);
        $_SESSION['user_id'] = $user->getId();
        header('Location:../index.php');
        die;
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../styles.css">
    <title>Registraion Page</title>
</head>
<body>
    <div class = "loginhead">
<nav><a href="login.php">Back to Login Page</a></nav>
    <h1 >Register your Account</h1>
    <?php foreach ($errorMessages as $error):?>
        <h2 style="color:red;"><?php print $error;?></h2>
        <?php endforeach?>
        </div>
    <form method="POST">
        <div>
            <label for="username">Username</label>
            <br>
            <input id="username" name="username" required>
        </div>
        <div>
            <label for="password">Password</label>
            <br>
            <input type="password" id="password" name="password" required>
        </div> 
        <div>
            <label for="password">Password confirmation</label>
            <br>
            <input type="password" id="password-verify" name="password-verify" required>
        </div>   
         <div>
            <input type="submit" id="register" name="register" value="Register new user">
        </div>
    </form>
</body>
</html>