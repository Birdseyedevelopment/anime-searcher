<?php
require_once('logintemplate/function.php');
require_once('logintemplate/User.php');
require_once('anime.php');
require_once('anime-function.php');
session_start();


$foundAnime = edu\ccp\cis44\normal\functions\findAnime($_GET['anime_name']);
$loggedIN = edu\ccp\cis44\login\functions\userisloggedIn();
Use Edu\Ccp\Cis244\login\User;
use function edu\ccp\cis44\login\functions\h;

if ($loggedIN){
    $user = User::getUserbyId($_SESSION['user_id']);
    } else {
        header('Location:logintemplate/login.php');
        die;

    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>anime detail page</title>
</head>
<body>
<div class = 'title'>
<nav><a href="logintemplate/logout.php">Logout</a></nav>

<form  method="GET">
        Search another:<input type="text" name="anime_name"><br>
    <input class=button  type ="submit" name="search" value="search anime">
</form>

    <h1>Anime Searcher</h1>
    <h3>HI! <?php print h  ($user->getUsername());?></h3>
   </div>
<nav>
    <ul>
        <button><a href="index.php">Home</a></button>
        <button><a href="new_anime.php">Add an Anime</a></button>
    </ul>
</nav>

<?php 
$animeObjects = $foundAnime;
$animeFound = false;
foreach ($animeObjects as $anime):
    if ($_GET['anime_name'] = $anime->getName()): 
        $animeFound = true;
?>
    <table class= 'table1'>
        <thead>
            <tr>
                <th class= 'name'>Anime Name</th>
                <th class= 'release_date'>Release Date</th>
                <th class= 'creator_name'>Creator</th>
                <th class= 'main_character'>Main Character</th>
                <tr>
        <td > <?php print h($anime->getName(), ENT_QUOTES); ?> </td>
   
        <td> <?php print h($anime->getDate(), ENT_QUOTES); ?> </td>

        <td> <?php print h($anime->getCreator(), ENT_QUOTES); ?> </td>

        <td> <?php print h($anime->getMainCharacter(), ENT_QUOTES); ?> </td>
        </tr>
        </tbody>
        
    </table>
    <table class= 'table2'>
    <thead>
            <tr><th class = 'description'>Description</th></tr>
        </thead>
        <tbody><tr>
            <td><?php print h($anime -> getDescripter(), ENT_QUOTES);?></td>
        </tr>
        <tr>
            <td><form method="POST" action= "edit_anime.php">
                    <input type="hidden" name="anime_id" value="<?php print $anime['anime_id']; ?>">
                    <input type="submit" value="Edit" name="edit">
                </form></td>
        </tr>
    </tbody>

    </table>
   <?php endif ;
    endforeach;
    if (!$animeFound):
    ?>
            <h2 class="error">Anime not Found</h2>
        <?php 
        endif;
        ?>
</body>
</html>