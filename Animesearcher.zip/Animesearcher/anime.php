<?php

namespace Edu\Ccp\Cis244\animesearch;

class Anime{
    private $anime_name;    
    private $release_date;
    private $creator_name;
    private $main_character;
    private $descripter;
  
    

    function __construct($anime_name, $release_date, $creator_name,$main_character, $descripter){
        $this->anime_name = $anime_name;        
        $this->release_date = $release_date;
        $this->creator_name = $creator_name;
        $this->main_character = $main_character;
        $this->descripter = $descripter; 
       }

        function getName(){
            return $this->anime_name;
        }

        function getDate(){

            return $this->release_date;
        }

        function getCreator(){
            return $this-> creator_name;
        }

        function getMaincharacter(){
            return $this-> main_character;
        }

        function getDescripter(){
            return $this->descripter;
        }


}

?>