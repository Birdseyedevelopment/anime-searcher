<?php
require_once('logintemplate/function.php');
require_once('logintemplate/User.php');
require_once('anime.php');
require_once('anime-function.php');
session_start();


$loggedIN = edu\ccp\cis44\login\functions\userisloggedIn();
Use Edu\Ccp\Cis244\login\User;
use function edu\ccp\cis44\login\functions\h;
use function edu\ccp\cis44\normal\functions\addNewAnime;
if ($loggedIN){
    $user = User::getUserbyId($_SESSION['user_id']);
    } else {
        header('Location:logintemplate/login.php');
        die;

    }


if(isset($_POST['edit'])){
    addNewAnime();
}
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Edit Anime</title>
</head>
<body>
<div class = 'title'>
<nav><a href="logintemplate/logout.php">Logout</a></nav>
<form  method="GET" action="animedetail.php">
        Search another:<input type="text" name="anime_name" placeholder="Search Your New Anime"><br>
    <input class=button  type ="submit" name="search" value="search anime">
</form>
<h1>Anime Editor</h1>
    <h3>HI! <?php print h  ($user->getUsername());?></h3>
   </div >
<nav>
    <button><a href="index.php">Home</a></button>
</nav>
<div>
   <form method = "POST">
    <label class= 'name' for="animename">Anime Name:</label>
    <input required="text" name= "animename" value="<?php print h($anime->getName(), ENT_QUOTES);?>">
<br>
<br>
    <label class= 'release_date' for="releasedate">Release Date:</label>
    <input required="text" name= "releasedate" value="<?php print h($anime->getDate(), ENT_QUOTES); ?>">
<br>
    <label class= 'creator_name' for="creatorname">Creator Name:</label>
    <input required="text" name= "creatorname" value=" <?php print h($anime->getCreator()); ?> ">
<br>
<br>
    <label class= 'main_character' for="maincharacter">Main Character:</label>
    <input required type="text" name= "maincharacter" value=" <?php print h($anime->getMainCharacter(), ENT_QUOTES); ?>">
<br>
<br>
    <label class = 'description' for="description">Description:</label>
    <textarea required name= "description" value="<?php print h($anime -> getDescripter(), ENT_QUOTES);?>" cols="30" rows="10"></textarea>
    <br><br>
    <input class=button  input="submit" name="edit" value="Edit anime">
</form> 
</div>
</body>
</html>