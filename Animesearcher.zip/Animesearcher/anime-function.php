<?php

namespace edu\ccp\cis44\normal\functions;
require_once('anime.php');
use Edu\Ccp\Cis244\animesearch\Anime;

const CONNECTION = 'sqlite:anime.db';

function getConnection(){
    return new \PDO(CONNECTION);
}

function getAnimeData(){

    $connection =getconnection();
    $query = $connection ->prepare('SELECT anime_name
    FROM anime order by anime_name ASC');
    $query->execute();
    $animes = $query -> fetchAll(\PDO::FETCH_ASSOC);
return $animes;
}

function addNewAnime(){
$connection = getConnection();
$queryString ='INSERT INTO anime (anime_name, release_date, creator_name, main_character, descripter) VALUES 
(:anime_name, :release_date, :creator_name, :main_character, :descriptor)';
$querydata =[
    ':anime_name'=>  htmlentities($_POST["animename"], ENT_QUOTES),
    ':release_date'=> htmlentities($_POST["releasedate"],ENT_QUOTES),
    ':creator_name'=> htmlentities($_POST["creatorname"],ENT_QUOTES),
    ':main_character'=> htmlentities($_POST["maincharacter"],ENT_QUOTES),
    ':descriptor'=> htmlentities($_POST["description"],ENT_QUOTES),
    
];
$query = $connection->prepare($queryString);
$query->execute($querydata);

}

function findAnime($animeName){
    $animeName =$_GET['anime_name'] ?? '';

    $animeNameParam = addcslashes($animeName,'_%').'%';
    $animeObjects =[];
    $connection =getconnection();
    $query = $connection ->prepare('SELECT anime_name, release_date, creator_name, main_character, descripter
FROM anime where anime_name LIKE :animename
');
$query->execute([':animename'=>$animeNameParam]);
$results = $query->fetchAll(\PDO::FETCH_ASSOC);
foreach($results as $anime){
    $animeObjects[]= new Anime ($anime['anime_name'], $anime['release_date'],  $anime['creator_name'], $anime['main_character'], $anime['descripter']); 
}

return $animeObjects;

}

function h($value){
    return htmlentities($value);
}


function editAnime() {
    $connection = getConnection();
    $queryString = 'UPDATE anime SET anime_name = :anime_name, release_date = :release_date, creator_name = :creator_name, main_character = :main_character, descriptor = :descriptor WHERE id = :id';
    $querydata = [
        ':id' => htmlentities($_POST["id"], ENT_QUOTES), // Assuming you have an 'id' field in your form
        ':anime_name' => htmlentities($_POST["animename"], ENT_QUOTES),
        ':release_date' => htmlentities($_POST["releasedate"], ENT_QUOTES),
        ':creator_name' => htmlentities($_POST["creatorname"], ENT_QUOTES),
        ':main_character' => htmlentities($_POST["maincharacter"], ENT_QUOTES),
        ':descriptor' => htmlentities($_POST["description"], ENT_QUOTES),
    ];
    $query = $connection->prepare($queryString);
    $query->execute($querydata);
}