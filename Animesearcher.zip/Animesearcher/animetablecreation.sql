DROP TABLE IF EXISTS anime;
CREATE TABLE anime(
anime_id INTEGER PRIMARY KEY AUTOINCREMENT,
anime_name TEXT,
release_date TEXT,
creator_name TEXT,
main_character TEXT,
descripter TEXT
);


INSERT INTO anime (anime_name, release_date, creator_name, main_character, descripter) VALUES 

('Dragon ball Z', 1989, 'Akira Toriyama', 'Son Goku', 'The story of Dragon Ball Z follows the life of Son Goku who discovers he is an alien from a distant planet called Vegeta and his adventure to protect his new home world earth and fight strong enemies.'),
('Yu Yu Hakusho', 1992, 'Yoshihiro Togashi', 'Yusuke Urameshi', 'YU YU hakusho is about a teenage troublemaker who is killed while trying to save the life of a child playing who is almost hit by a car. Yusuke Urameshi is sent to the after life and make a deal with the ruler to come back as a spirit detective to make up for his troubled life.'),
('Naruto', 2002,'Masashi Kishimoto', 'Naruto Uzumaki', 'Naruto follows the story of Naruto Uzumaki, a town troublemaker who one day has hope of becoming the leader of his village to gain the respect and admiration of its people. All while trying to control the power of a demon seal inside of him.'),
('One Piece', 1999, 'Eiichiro Oda', 'Monkey D. Luffy', 'The story of One piece follows the life of a young pirate named Monkey D. Luffy as he sets sails on the high seas to find the legendary treasure called One Piece. On his adventure he finds a crew and fights the world government and rival pirate crew trying to find it first.'),
('Bleach', 2004, 'Tite Kubo', 'Ichigo Kurosaki', 'Bleach is about a young high schooler named Ichigo Kurosaki who can see ghosts. One day he is crosses a path with soul reaper and is given the same powers to protect his friends and his hometown from creatures known as hollows that are evil spirits that plauge the spirit world.'),
('Konosuba: Gods Blessing on This Wonderful World', 2016, 'Natsume Akatsuki', 'Kazuma Satou', 'This show follows  Kazuma Satou, a boy who is sent to a fantasy world with MMORPG elements after his death. it follows his adventures with the group that he pulls together after arriving in the strange new world.'),
('Attack on Titan', 2013, 'Hajime Isayama', 'Eren Yeager', 'Attack on Titan follows the lives of Eren Yeager and his team mates as they try and struggle to defend their home from man-eating giants called titans. After discovering that he can transform into one of these titans Eren vows to destroy all the titans.'),
('JoJos Bizarre Adventure', 2012, 'Hirohiko Araki', 'JoJo', 'JoJos Bizarre Adventure is follows the family line of the Joestar family across generations from the end of the 19th century up to modern times as they go through their lives and fight incoming enemies that challenge them.'),
('Blue lock', 2022, 'Muneyuki Kaneshiro', 'Isagi Yoichi', 'Blue Lock follows the story of Isagi Yoichi as he gets accepted to a special school to become a number one soccer striker and join the national team as the newest student in the in the school he must try to find his own way to become the best striker in the Blue Lock.'),
('Gurren Lagann', 2007, 'Kazuki Nakashima', 'Simon', 'This series follows the story of brothers simon and Kamina who lived in a subterranean village and want to go to the surface, using a found mecha known as Laggan the get to the surface and they join the fight with the humans against the forces of Lordgenome.');


select descripter from anime WHERE anime_name = 'Naruto';