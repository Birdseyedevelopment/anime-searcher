const anime_api = "https://api.myanimelist.net/v2/anime/{anime_id}";

async function animeDetail(){

    const response = await fetch(anime_api);
    const data = await response.json();
console.log (data.results);
};

animeDetail();