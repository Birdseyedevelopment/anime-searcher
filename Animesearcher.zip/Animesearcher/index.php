<?php

require_once('logintemplate/User.php');
require_once('logintemplate/function.php');
require_once('anime-function.php');
session_start();
use Edu\Ccp\Cis244\login\User;
use function edu\ccp\cis44\normal\functions\getAnimeData;
use function edu\ccp\cis44\login\functions\h;
$loggedIN = edu\ccp\cis44\login\functions\userisloggedIn();

$animeavailable = getAnimeData();
if ($loggedIN){
    $user = User::getUserbyId($_SESSION['user_id']);
    } else {
        header('Location:logintemplate/login.php');
        die;

    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>ANIME SEARCHER</title>
</head>
<body>
    <div class= 'title'>
<nav><a href="logintemplate/logout.php">Logout</a></nav>

<h1>ANIME SEARCHER</h1>
</div>
  <div class='searchbox'>
    <form  method="GET" action="animedetail.php">
        Search:<input type="text" name="anime_name"><br>
    <input class=button  type ="submit" name="search" value="search anime">

</form>
   </div> 

   <div>
    <h2>Available Anime to Search</h2>
    <?php
    foreach ($animeavailable as $anime):
    ?>
    <table class= 'table'>
       <tr>
           
        <td class= 'name'> <?php print h($anime['anime_name']); ?> </td>
        </tr>
        </tbody>
        
    </table>
    <?php
    endforeach;
    ?>
   </div>
   <script src="script.js"></script>
</body>
</html>